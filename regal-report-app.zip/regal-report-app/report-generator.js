const pptxgen = require("pptxgenjs");

// ── Colors ────────────────────────────────────────────────────────────────────
const NAVY = "1A2B4A", GOLD = "C9A84C", LIGHT_GOLD = "E8D5A0";
const WHITE = "FFFFFF", LIGHT_BG = "F4F6FA";
const DARK_TEXT = "1A2B4A", MID_TEXT = "4A5568";
const ACCENT_GREEN = "0E7A5F", ACCENT_RED = "C53030";

const makeShadow = () => ({ type: "outer", blur: 8, offset: 3, angle: 45, color: "000000", opacity: 0.10 });

function cr(n) { return n == null ? "—" : ("Rs." + Number(n).toLocaleString("en-IN")); }
function crore(n) { return n == null ? "—" : ("Rs." + (n / 1e7).toFixed(2) + " Cr"); }
function lakh(n)  { return n == null ? "—" : ("Rs." + (n / 1e5).toFixed(2) + " L"); }
function sum(arr) { return (arr || []).reduce((a, b) => a + (b || 0), 0); }

function headerBar(s, title, sub) {
  s.addShape(s.pres ? s.pres.shapes.RECTANGLE : undefined, {
    x: 0, y: 0, w: 10, h: 0.85, fill: { color: NAVY }, line: { color: NAVY }
  });
  s.addText(title, { x: 0.5, y: 0.08, w: 9, h: 0.45, fontSize: 20, bold: true, color: WHITE, fontFace: "Cambria" });
  if (sub) s.addText(sub, { x: 0.5, y: 0.56, w: 9, h: 0.25, fontSize: 11, color: LIGHT_GOLD, fontFace: "Calibri" });
}

function makeTableData(rows, { amtCol = null, totalRows = [] } = {}) {
  return rows.map((row, ri) => row.map((cell, ci) => {
    const isHeader = ri === 0;
    const isTotal = totalRows.includes(ri) || ri === rows.length - 1;
    const isAmt = amtCol != null && ci === amtCol && !isHeader;
    return {
      text: String(cell ?? "—"),
      options: {
        bold: isHeader || isTotal,
        color: isHeader ? WHITE : (isTotal ? NAVY : (isAmt ? ACCENT_GREEN : DARK_TEXT)),
        fill: isHeader ? { color: NAVY } : (isTotal ? { color: "E8D5A0" } : (ri % 2 === 0 ? { color: "EEF2F9" } : { color: WHITE })),
        align: (amtCol != null && ci >= amtCol) ? "right" : (ci === 0 ? "left" : "center"),
        fontSize: isHeader ? 9.5 : 9,
        fontFace: "Calibri",
        border: [{ pt: 0.5, color: "D0D8E8" }, { pt: 0.5, color: "D0D8E8" }, { pt: 0.5, color: "D0D8E8" }, { pt: 0.5, color: "D0D8E8" }]
      }
    };
  }));
}

async function generatePresentation(data, outputPath) {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.title = `Regal Group Fund Position ${data.reportDate || ""}`;

  const d = data;
  const date = d.reportDate || "—";

  // ── Helper so shapes can reference pres ──────────────────────────────────
  function addHeaderBar(s, title, sub) {
    s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.85, fill: { color: NAVY }, line: { color: NAVY } });
    s.addText(title, { x: 0.5, y: 0.08, w: 9, h: 0.45, fontSize: 20, bold: true, color: WHITE, fontFace: "Cambria" });
    if (sub) s.addText(sub, { x: 0.5, y: 0.56, w: 9, h: 0.25, fontSize: 11, color: LIGHT_GOLD, fontFace: "Calibri" });
  }

  // ── Totals ──────────────────────────────────────────────────────────────────
  const ent = d.entities || {};
  const rj   = ent.regalJewellersPvtLtd       || {};
  const rji  = ent.regalJewellersIndiaPvtLtd  || {};
  const opt  = ent.optimumJewellersLlp         || {};

  const totalSanctioned = (rj.sanctioned || 0) + (rji.sanctioned || 0) + (opt.sanctioned || 0);
  const totalAvailed    = (rj.availed    || 0) + (rji.availed    || 0) + (opt.availed    || 0);
  const totalUtilised   = (rj.utilised   || 0) + (rji.utilised   || 0) + (opt.utilised   || 0);
  const totalAvailable  = (rj.available  || 0) + (rji.available  || 0) + (opt.available  || 0);
  const grandAvailable  = totalAvailable + (d.currentAccountBalance || 0);

  // ── SLIDE 1: Title ───────────────────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: NAVY };
    s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: GOLD }, line: { color: GOLD } });
    s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 5.545, w: 10, h: 0.08, fill: { color: GOLD }, line: { color: GOLD } });
    s.addShape(pres.shapes.OVAL, { x: 6.5, y: -1.2, w: 5, h: 5, fill: { color: GOLD, transparency: 85 }, line: { color: GOLD, transparency: 70, width: 1 } });
    s.addText("REGAL GROUP OF COMPANIES", { x: 0.6, y: 1.0, w: 8.5, h: 0.5, fontSize: 13, bold: true, color: LIGHT_GOLD, fontFace: "Calibri", charSpacing: 3 });
    s.addText("Fund Position Status", { x: 0.6, y: 1.55, w: 8.5, h: 1.1, fontSize: 46, bold: true, color: WHITE, fontFace: "Cambria" });
    s.addShape(pres.shapes.RECTANGLE, { x: 0.6, y: 2.85, w: 3.0, h: 0.05, fill: { color: GOLD }, line: { color: GOLD } });
    s.addText(`As on ${date}`, { x: 0.6, y: 3.05, w: 6, h: 0.45, fontSize: 18, color: LIGHT_GOLD, fontFace: "Calibri" });

    const stats = [
      { label: "Total Sanctioned", val: crore(totalSanctioned) },
      { label: "Total Utilised",   val: crore(totalUtilised) },
      { label: "Total Available",  val: crore(grandAvailable) },
    ];
    stats.forEach((st, i) => {
      const x = 0.6 + i * 3.1;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 3.75, w: 2.8, h: 1.3, fill: { color: WHITE, transparency: 90 }, line: { color: GOLD, width: 1 }, rectRadius: 0.08 });
      s.addText(st.val, { x: x + 0.1, y: 3.82, w: 2.6, h: 0.65, fontSize: 20, bold: true, color: GOLD, fontFace: "Cambria", align: "center" });
      s.addText(st.label, { x: x + 0.1, y: 4.47, w: 2.6, h: 0.4, fontSize: 11, color: WHITE, fontFace: "Calibri", align: "center" });
    });
  }

  // ── SLIDE 2: Consolidated Overview ───────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    addHeaderBar(s, "CONSOLIDATED FUND OVERVIEW", `As on ${date}`);

    const entities = [
      { name: "Regal Jewellers Pvt Ltd",         data: rj,  pct: rj.sanctioned ? Math.round((rj.utilised||0)*100/rj.sanctioned) : 0 },
      { name: "Regal Jewellers India Pvt Ltd",    data: rji, pct: rji.sanctioned ? Math.round((rji.utilised||0)*100/rji.sanctioned) : 0 },
      { name: "Optimum Jewellers LLP",            data: opt, pct: opt.sanctioned ? Math.round((opt.utilised||0)*100/opt.sanctioned) : 0 },
      { name: "Current Account Balances",         data: { available: d.currentAccountBalance }, pct: null },
    ];

    entities.forEach((e, i) => {
      const x = 0.3 + (i % 2) * 4.85;
      const y = 1.15 + Math.floor(i / 2) * 2.1;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 4.55, h: 1.9, fill: { color: WHITE }, line: { color: "D0D8E8", width: 1 }, rectRadius: 0.1, shadow: makeShadow() });
      s.addText(e.name, { x: x + 0.15, y: y + 0.1, w: 4.2, h: 0.4, fontSize: 12, bold: true, color: NAVY, fontFace: "Cambria" });

      if (e.pct !== null) {
        s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.15, y: y + 0.55, w: 4.2, h: 0.18, fill: { color: "D0D8E8" }, line: { color: "D0D8E8" }, rectRadius: 0.05 });
        const fillW = Math.max(0.2, 4.2 * (e.pct / 100));
        const barColor = e.pct > 90 ? ACCENT_RED : e.pct > 75 ? "E07B00" : ACCENT_GREEN;
        s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.15, y: y + 0.55, w: fillW, h: 0.18, fill: { color: barColor }, line: { color: barColor }, rectRadius: 0.05 });
        s.addText(`${e.pct}% utilised`, { x: x + 0.15, y: y + 0.75, w: 4.2, h: 0.25, fontSize: 10, color: MID_TEXT, fontFace: "Calibri" });
      }

      const ed = e.data;
      [
        { lbl: "Sanctioned", val: crore(ed.sanctioned) },
        { lbl: "Availed",    val: crore(ed.availed) },
        { lbl: "Available",  val: crore(ed.available) },
      ].forEach((c, ci) => {
        const cx = x + 0.15 + ci * 1.4;
        s.addText(c.lbl, { x: cx, y: y + 1.1,  w: 1.35, h: 0.25, fontSize: 9,  color: MID_TEXT,      fontFace: "Calibri" });
        s.addText(c.val, { x: cx, y: y + 1.35, w: 1.35, h: 0.35, fontSize: 11, bold: true, color: c.lbl === "Available" ? ACCENT_GREEN : DARK_TEXT, fontFace: "Calibri" });
      });
    });

    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.3, y: 5.1, w: 9.4, h: 0.42, fill: { color: NAVY }, line: { color: NAVY }, rectRadius: 0.06 });
    s.addText(`TOTAL AVAILABLE LIMIT (CC + Current A/c):   ${crore(grandAvailable)}`, { x: 0.5, y: 5.13, w: 9, h: 0.35, fontSize: 13, bold: true, color: GOLD, fontFace: "Calibri", align: "center" });
  }

  // ── SLIDE 3: CC Limits – Regal Jewellers PVT LTD ────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    addHeaderBar(s, "CC LIMITS – REGAL JEWELLERS PRIVATE LIMITED",
      `Total Sanctioned: ${crore(rj.sanctioned)}  |  Availed: ${crore(rj.availed)}  |  Utilised: ${crore(rj.utilised)}  |  Available: ${crore(rj.available)}`);

    const banks = (rj.banks || []);
    const rows = [["Bank", "Nature", "Sanction Date", "Sanctioned (Cr)", "Availed (Cr)", "Utilised (Cr)", "Available"]].concat(
      banks.map(b => [
        `${b.name}${b.accountNo ? ` (${b.accountNo})` : ""}`,
        b.nature || "CC",
        b.sanctionDate || "—",
        b.sanctioned ? (b.sanctioned / 1e7).toFixed(2) : "—",
        b.availed    ? (b.availed    / 1e7).toFixed(2) : "—",
        b.utilised   ? (b.utilised   / 1e7).toFixed(2) : "—",
        b.available  ? (b.available > 1e7 ? (b.available/1e7).toFixed(2)+" Cr" : (b.available/1e5).toFixed(2)+" L") : "—",
      ])
    );
    s.addTable(makeTableData(rows, { amtCol: 3, totalRows: [] }), {
      x: 0.3, y: 1.05, w: 9.4, rowH: 0.38, colW: [2.5, 0.6, 1.1, 1.15, 1.0, 1.05, 1.0]
    });
  }

  // ── SLIDE 4: CC Limits – Other Entities ─────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    addHeaderBar(s, "CC LIMITS – OTHER ENTITIES", null);

    const makeEntityTable = (label, entity, y) => {
      s.addText(label, { x: 0.4, y, w: 9, h: 0.35, fontSize: 13, bold: true, color: NAVY, fontFace: "Cambria" });
      const banks = entity.banks || [];
      const rows = [["Bank", "Nature", "Sanctioned (Cr)", "Availed (Cr)", "Utilised (Cr)", "Available"]].concat(
        banks.map(b => [
          `${b.name}${b.accountNo ? ` (${b.accountNo})` : ""}`,
          b.nature || "CC",
          b.sanctioned ? (b.sanctioned/1e7).toFixed(2) : "—",
          b.availed    ? (b.availed/1e7).toFixed(2)    : "—",
          b.utilised   ? (b.utilised/1e7).toFixed(2)   : "—",
          b.available  ? (b.available > 1e7 ? (b.available/1e7).toFixed(2)+" Cr" : (b.available/1e5).toFixed(2)+" L") : "—",
        ])
      ).concat([[
        "TOTAL", "",
        (entity.sanctioned/1e7).toFixed(2),
        (entity.availed/1e7).toFixed(2),
        (entity.utilised/1e7).toFixed(2),
        entity.available > 1e7 ? (entity.available/1e7).toFixed(2)+" Cr" : (entity.available/1e5).toFixed(2)+" L"
      ]]);
      s.addTable(makeTableData(rows, { amtCol: 2, totalRows: [rows.length - 1] }), {
        x: 0.4, y: y + 0.38, w: 9.2, rowH: 0.38, colW: [3.2, 0.8, 1.5, 1.5, 1.5, 1.3]
      });
    };

    makeEntityTable("Regal Jewellers India Private Limited", rji, 0.98);
    makeEntityTable("Optimum Jewellers LLP", opt, 2.98);
  }

  // ── SLIDE 5: Daily Cash Flow ─────────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    addHeaderBar(s, "DAILY CASH FLOW STATEMENT", null);

    const cf = d.cashFlow || {};
    const dates = cf.dates || [];
    const inflows  = cf.totalInflow  || [];
    const outflows = cf.totalOutflow || [];

    const inCr  = inflows.map(v  => +(v / 1e7).toFixed(2));
    const outCr = outflows.map(v => +(v / 1e7).toFixed(2));

    s.addChart(pres.charts.BAR,
      [{ name: "Cash Inflow (Rs. Cr)", labels: dates, values: inCr },
       { name: "Cash Outflow (Rs. Cr)", labels: dates, values: outCr }],
      { x: 0.3, y: 0.95, w: 5.8, h: 3.5, barDir: "col", barGrouping: "clustered",
        chartColors: [GOLD, "4A90D9"],
        chartArea: { fill: { color: WHITE }, roundedCorners: true },
        catAxisLabelColor: MID_TEXT, valAxisLabelColor: MID_TEXT,
        valGridLine: { color: "E2E8F0", size: 0.5 }, catGridLine: { style: "none" },
        showValue: true, dataLabelColor: DARK_TEXT, dataLabelFontSize: 9,
        showLegend: true, legendPos: "b", legendFontSize: 10,
        showTitle: true, title: "Cash Inflow vs Outflow (Rs. Crore)",
        titleFontSize: 12, titleColor: NAVY, titleFontFace: "Cambria" });

    const categories = [
      { lbl: "Cash Sales",        vals: cf.totalSales },
      { lbl: "Old Gold Purchase", vals: cf.totalOldGold },
      { lbl: "Scheme Collection", vals: cf.totalSchemes },
      { lbl: "Bank Loan Inflow",  vals: cf.loanInflow },
    ];

    const cfRows = [["Category"].concat(dates).concat(["TOTAL"])].concat(
      categories.map(c => {
        const vals = (c.vals || []);
        return [c.lbl].concat(vals.map(v => crore(v))).concat([crore(sum(vals))]);
      })
    ).concat([
      ["TOTAL INFLOW"].concat(inflows.map(v => crore(v))).concat([crore(sum(inflows))]),
      ["Gold Purchase Pmt"].concat((cf.goldPurchasePayments || []).map(v => crore(v))).concat([crore(sum(cf.goldPurchasePayments))]),
      ["Opex"].concat((cf.opex || []).map(v => crore(v))).concat([crore(sum(cf.opex))]),
      ["Capex"].concat((cf.capex || []).map(v => crore(v))).concat([crore(sum(cf.capex))]),
      ["Tax"].concat((cf.taxPayments || []).map(v => crore(v))).concat([crore(sum(cf.taxPayments))]),
      ["TOTAL OUTFLOW"].concat(outflows.map(v => crore(v))).concat([crore(sum(outflows))]),
    ]);

    const subtotalRows = [4, cfRows.length - 1];
    s.addTable(makeTableData(cfRows, { amtCol: 1, totalRows: subtotalRows }), {
      x: 6.35, y: 0.95, w: 3.35, rowH: 0.3, colW: [1.5].concat(dates.map(() => (1.7 / dates.length))).concat([0.6])
    });

    const nets = inflows.map((v, i) => v - (outflows[i] || 0));
    const netStr = dates.map((dd, i) => `${dd}: +${crore(nets[i])}`).join("    |    ");
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.3, y: 4.62, w: 9.4, h: 0.85, fill: { color: NAVY }, line: { color: NAVY }, rectRadius: 0.08 });
    s.addText(`Net Cash Position:   ${netStr}`, { x: 0.5, y: 4.72, w: 9.0, h: 0.45, fontSize: 12, bold: true, color: GOLD, fontFace: "Calibri", align: "center" });
  }

  // ── SLIDE 6: Cash Outflow Details ────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    addHeaderBar(s, `CASH OUTFLOW DETAILS – ${date}`, null);

    const cf = d.cashFlow || {};
    const lastOutflow = (cf.totalOutflow || []).slice(-1)[0] || 0;
    const goldPmt = sum(cf.goldPurchasePayments);
    const opexPmt = sum(cf.opex);
    const capexPmt = sum(cf.capex);
    const salPmt  = sum(cf.salary);
    const taxPmt  = sum(cf.taxPayments);

    s.addChart(pres.charts.PIE, [{
      name: "Outflow Mix",
      labels: ["Jewellery Purchase", "Opex", "Capex", "Salary", "Tax"],
      values: [goldPmt/1e5, opexPmt/1e5, capexPmt/1e5, salPmt/1e5, taxPmt/1e5]
    }], {
      x: 0.3, y: 0.95, w: 4.5, h: 3.8,
      chartColors: [NAVY, GOLD, "4A90D9", ACCENT_GREEN, ACCENT_RED],
      chartArea: { fill: { color: WHITE }, roundedCorners: true },
      showPercent: true, showLegend: true, legendPos: "b", legendFontSize: 10,
      dataLabelColor: WHITE, dataLabelFontSize: 10,
      showTitle: true, title: "Outflow Breakdown", titleFontSize: 12, titleColor: NAVY, titleFontFace: "Cambria"
    });

    const outItems = [
      { label: "Jewellery Purchase Payments", amt: crore(goldPmt), color: NAVY, sub: `${(d.jewelleryVendorPayments||[]).length} vendors` },
      { label: "Opex Payments",               amt: lakh(opexPmt),  color: "1B5E8A", sub: `${(d.opexPayments||[]).length} parties` },
      { label: "Capex Payments",              amt: lakh(capexPmt), color: "6B3A8A", sub: `${(d.capexPayments||[]).length} parties` },
      { label: "Salary Advances",             amt: cr(salPmt),     color: ACCENT_GREEN, sub: `${(d.salaryPayments||[]).length} employees` },
      { label: "Tax Payments (TDS)",          amt: lakh(taxPmt),   color: ACCENT_RED, sub: `${(d.taxPayments||[]).length} units` },
    ];
    outItems.forEach((item, i) => {
      const x = 5.1, y = 0.98 + i * 0.88;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 4.6, h: 0.78, fill: { color: WHITE }, line: { color: "D0D8E8", width: 1 }, rectRadius: 0.08, shadow: makeShadow() });
      s.addShape(pres.shapes.RECTANGLE, { x, y, w: 0.22, h: 0.78, fill: { color: item.color }, line: { color: item.color } });
      s.addText(item.label, { x: x + 0.3, y: y + 0.06, w: 3.0, h: 0.3, fontSize: 10, bold: true, color: DARK_TEXT, fontFace: "Calibri" });
      s.addText(item.sub,   { x: x + 0.3, y: y + 0.38, w: 3.0, h: 0.28, fontSize: 9, color: MID_TEXT, fontFace: "Calibri" });
      s.addText(item.amt,   { x: x + 3.3, y: y + 0.06, w: 1.1, h: 0.62, fontSize: 13, bold: true, color: item.color, fontFace: "Cambria", align: "right", valign: "middle" });
    });

    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.3, y: 5.1, w: 9.4, h: 0.42, fill: { color: GOLD }, line: { color: GOLD }, rectRadius: 0.06 });
    s.addText(`GRAND TOTAL OUTFLOW (${date}):   ${crore(lastOutflow)}`, { x: 0.5, y: 5.13, w: 9, h: 0.35, fontSize: 13, bold: true, color: NAVY, fontFace: "Calibri", align: "center" });
  }

  // ── SLIDE 7: Current Account Balances ────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    addHeaderBar(s, "CURRENT ACCOUNT BALANCES", `As on ${date}  |  Total: ${crore(d.currentAccountBalance)}`);

    const accounts = (d.currentAccounts || []).sort((a, b) => (b.amount || 0) - (a.amount || 0)).slice(0, 12);
    const rows = [["Entity / Location", "State", "Bank", "Balance"]].concat(
      accounts.map(a => [a.entity || a.location || "—", a.state || "—", a.bank || "—", cr(a.amount)])
    );
    s.addTable(makeTableData(rows, { amtCol: 3, totalRows: [] }), {
      x: 0.3, y: 0.95, w: 9.4, rowH: 0.39, colW: [3.8, 1.2, 2.0, 1.8]
    });
  }

  // ── SLIDE 8: Key Highlights ───────────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: NAVY };
    s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.08, fill: { color: GOLD }, line: { color: GOLD } });
    s.addShape(pres.shapes.RECTANGLE, { x: 0, y: 5.545, w: 10, h: 0.08, fill: { color: GOLD }, line: { color: GOLD } });

    s.addText("KEY HIGHLIGHTS & SUMMARY", { x: 0.6, y: 0.22, w: 8.5, h: 0.5, fontSize: 22, bold: true, color: WHITE, fontFace: "Cambria" });

    const cf = d.cashFlow || {};
    const totalSalesAmt = sum(cf.totalSales);
    const totalSchemesAmt = sum(cf.totalSchemes);
    const loanAmt = sum(cf.loanInflow);

    const highlights = [
      { icon: "CC",   title: "Total CC Limit",       val: crore(totalSanctioned), sub: "Across 3 entities" },
      { icon: "UTIL", title: "Overall Utilisation",  val: totalSanctioned ? Math.round(totalUtilised*100/totalSanctioned)+"%" : "—", sub: "of sanctioned limit" },
      { icon: "AVAIL",title: "Net Available",         val: crore(grandAvailable), sub: "CC + Current A/c" },
      { icon: "SALES",title: "Sales Collection",      val: crore(totalSalesAmt),  sub: `Over ${(cf.dates||[]).length} days` },
      { icon: "SCHM", title: "Scheme Collections",    val: crore(totalSchemesAmt),sub: `Over ${(cf.dates||[]).length} days` },
      { icon: "LOAN", title: "Loan Drawdowns",        val: crore(loanAmt),        sub: "Total bank loan inflow" },
    ];

    highlights.forEach((h, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.4 + col * 3.1, y = 0.95 + row * 2.15;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.9, h: 1.95, fill: { color: WHITE, transparency: 92 }, line: { color: GOLD, width: 1 }, rectRadius: 0.1 });
      s.addShape(pres.shapes.OVAL, { x: x + 0.15, y: y + 0.12, w: 0.5, h: 0.5, fill: { color: GOLD }, line: { color: GOLD } });
      s.addText(h.icon, { x: x + 0.15, y: y + 0.12, w: 0.5, h: 0.5, fontSize: 7, bold: true, color: NAVY, fontFace: "Calibri", align: "center", valign: "middle", margin: 0 });
      s.addText(h.title, { x: x + 0.15, y: y + 0.6,  w: 2.6, h: 0.3,  fontSize: 10, color: LIGHT_GOLD, fontFace: "Calibri", bold: true });
      s.addText(h.val,   { x: x + 0.15, y: y + 0.9,  w: 2.6, h: 0.5,  fontSize: 14, bold: true, color: WHITE, fontFace: "Cambria" });
      s.addText(h.sub,   { x: x + 0.15, y: y + 1.42, w: 2.6, h: 0.4,  fontSize: 9, color: LIGHT_GOLD, fontFace: "Calibri" });
    });

    s.addText(`REGAL GROUP OF COMPANIES  ·  FUND POSITION REPORT  ·  ${date}`, { x: 0.5, y: 5.2, w: 9, h: 0.28, fontSize: 9, color: LIGHT_GOLD, fontFace: "Calibri", align: "center", charSpacing: 1 });
  }

  // ── SLIDE 9: Jewellery Vendor Payments ───────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    const payments = d.jewelleryVendorPayments || [];
    const total = sum(payments.map(p => p.amount));
    addHeaderBar(s, "JEWELLERY PURCHASE VENDOR PAYMENTS", `Date: ${date}  |  Total: ${cr(total)}`);

    const rows = [["Party Name", "Nature", "Type", "Showroom", "Amount (Rs.)"]].concat(
      payments.map(p => [p.party, p.nature || "Jewellery Purchase", p.type || "Credit", p.showroom || "—", cr(p.amount)])
    ).concat([["TOTAL", "", "", "", cr(total)]]);

    s.addTable(makeTableData(rows, { amtCol: 4, totalRows: [rows.length - 1] }), {
      x: 0.3, y: 0.95, w: 9.4, rowH: 0.41, colW: [3.0, 2.0, 0.9, 1.1, 1.8]
    });

    if (payments.length > 0) {
      s.addChart(pres.charts.BAR, [{
        name: "Amount (L Rs.)",
        labels: payments.map(p => p.party),
        values: payments.map(p => +(((p.amount||0)/1e5).toFixed(1)))
      }], {
        x: 0.3, y: 4.7, w: 9.4, h: 0.78,
        barDir: "bar", chartColors: [NAVY],
        chartArea: { fill: { color: WHITE } },
        catAxisLabelColor: MID_TEXT, valAxisLabelColor: MID_TEXT,
        catGridLine: { style: "none" }, valGridLine: { color: "E2E8F0", size: 0.5 },
        showValue: true, dataLabelColor: DARK_TEXT, dataLabelFontSize: 8,
        showLegend: false, catAxisLabelFontSize: 7, valAxisLabelFontSize: 7, showTitle: false
      });
    }
  }

  // ── SLIDE 10: Opex Payments ──────────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    const payments = d.opexPayments || [];
    const total = sum(payments.map(p => p.amount));
    addHeaderBar(s, "OPEX PAYMENTS", `Date: ${date}  |  Total: ${lakh(total)}`);

    const rows = [["Party Name", "Type", "Showroom", "Amount (Rs.)"]].concat(
      payments.map(p => [p.party, p.type || "Credit", p.showroom || "—", cr(p.amount)])
    ).concat([["TOTAL", "", "", cr(total)]]);

    s.addTable(makeTableData(rows, { amtCol: 3, totalRows: [rows.length - 1] }), {
      x: 0.3, y: 0.93, w: 9.4, rowH: 0.215, colW: [4.2, 1.0, 1.7, 1.8]
    });
  }

  // ── SLIDE 11: Capex Payments ─────────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    const payments = d.capexPayments || [];
    const total = sum(payments.map(p => p.amount));
    addHeaderBar(s, "CAPEX PAYMENTS", `Date: ${date}  |  Total: ${lakh(total)}`);

    const rows = [["Party Name", "Type", "Showroom / Location", "Amount (Rs.)"]].concat(
      payments.map(p => [p.party, p.type || "Credit", p.showroom || "—", cr(p.amount)])
    ).concat([["TOTAL", "", "", cr(total)]]);

    s.addTable(makeTableData(rows, { amtCol: 3, totalRows: [rows.length - 1] }), {
      x: 0.3, y: 0.95, w: 6.0, rowH: 0.385, colW: [2.7, 0.85, 1.4, 1.35]
    });

    if (payments.length > 0) {
      const top6 = [...payments].sort((a, b) => b.amount - a.amount).slice(0, 6);
      s.addChart(pres.charts.PIE, [{
        name: "Capex Mix",
        labels: top6.map(p => p.party),
        values: top6.map(p => +(((p.amount||0)/1e5).toFixed(1)))
      }], {
        x: 6.55, y: 0.95, w: 3.15, h: 3.4,
        chartColors: [NAVY, GOLD, "4A90D9", ACCENT_GREEN, "8B5CF6", "E07B00"],
        chartArea: { fill: { color: WHITE }, roundedCorners: true },
        showPercent: true, showLegend: true, legendPos: "b", legendFontSize: 7,
        dataLabelColor: WHITE, dataLabelFontSize: 9,
        showTitle: true, title: "Capex Split", titleFontSize: 11, titleColor: NAVY, titleFontFace: "Cambria"
      });
    }
  }

  // ── SLIDE 12: Sales Collection – Branch-wise ─────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    const cf = d.cashFlow || {};
    const dates = cf.dates || [];
    const byBranch = cf.salesByBranch || {};
    const branches = Object.keys(byBranch).filter(b => byBranch[b] && byBranch[b].some(v => v > 0));
    const totals = cf.totalSales || [];

    addHeaderBar(s, "SALES COLLECTION - BRANCH-WISE", `Period: ${dates.join(" to ")}  |  All figures in Rs.`);

    const rows = [["Branch"].concat(dates).concat(["3-Day Total"])].concat(
      branches.map(b => {
        const vals = byBranch[b] || [];
        return [b].concat(vals.map(v => cr(v))).concat([cr(sum(vals))]);
      })
    ).concat([["TOTAL"].concat(totals.map(v => cr(v))).concat([cr(sum(totals))])]);

    s.addTable(makeTableData(rows, { amtCol: 1, totalRows: [rows.length - 1] }), {
      x: 0.3, y: 0.93, w: 5.85, rowH: 0.295,
      colW: [0.9].concat(dates.map(() => 1.2)).concat([1.35])
    });

    const branchTotals = branches.map(b => {
      const vals = byBranch[b] || [];
      return +(sum(vals) / 1e5).toFixed(1);
    });

    if (branches.length > 0) {
      s.addChart(pres.charts.BAR, [{
        name: "3-Day Sales (L Rs.)",
        labels: branches,
        values: branchTotals
      }], {
        x: 6.3, y: 0.93, w: 3.4, h: 4.6, barDir: "bar",
        chartColors: [GOLD],
        chartArea: { fill: { color: WHITE }, roundedCorners: true },
        catAxisLabelColor: MID_TEXT, valAxisLabelColor: MID_TEXT,
        catGridLine: { style: "none" }, valGridLine: { color: "E2E8F0", size: 0.5 },
        showValue: true, dataLabelColor: DARK_TEXT, dataLabelFontSize: 7.5,
        showLegend: false, catAxisLabelFontSize: 8, valAxisLabelFontSize: 7,
        showTitle: true, title: "Branch Sales (L Rs.)", titleFontSize: 10, titleColor: NAVY, titleFontFace: "Cambria"
      });
    }

    const bestDay = totals.indexOf(Math.max(...totals));
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.3, y: 5.1, w: 5.85, h: 0.42, fill: { color: NAVY }, line: { color: NAVY }, rectRadius: 0.06 });
    s.addText(`Total: ${crore(sum(totals))}  |  Best Day: ${dates[bestDay] || "—"} (${crore(totals[bestDay])})`, { x: 0.4, y: 5.13, w: 5.65, h: 0.35, fontSize: 8.5, bold: true, color: GOLD, fontFace: "Calibri", align: "center" });
  }

  // ── SLIDE 13: Scheme Collection ───────────────────────────────────────────────
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };
    const cf = d.cashFlow || {};
    const dates = cf.dates || [];
    const schemes = cf.schemeCollections || {};
    const totalSchemes = cf.totalSchemes || [];

    addHeaderBar(s, "SCHEME COLLECTION", `Period: ${dates.join(" to ")}  |  3-Day Total: ${cr(sum(totalSchemes))}`);

    const schemeNames = { Regalia: "Regalia", Akshyanidhi: "Akshyanidhi", GoldGram: "Gold Gram (Pay Sharp)", Swarnaraksha: "Swarnaraksha Plus", Swayamvara: "Swayamvara" };

    const rows = [["Scheme"].concat(dates).concat(["3-Day Total"])].concat(
      Object.entries(schemeNames).map(([key, label]) => {
        const vals = schemes[key] || [];
        return [label].concat(vals.map(v => cr(v))).concat([cr(sum(vals))]);
      })
    ).concat([["TOTAL"].concat(totalSchemes.map(v => cr(v))).concat([cr(sum(totalSchemes))])]);

    s.addTable(makeTableData(rows, { amtCol: 1, totalRows: [rows.length - 1] }), {
      x: 0.3, y: 0.95, w: 9.4, rowH: 0.52, colW: [2.4].concat(dates.map(() => 1.65)).concat([1.7])
    });

    if (Object.keys(schemes).length > 0) {
      s.addChart(pres.charts.BAR,
        [{ name: "22-Jun", labels: Object.values(schemeNames), values: Object.keys(schemeNames).map(k => +((schemes[k]||[])[0]||0)/1e5) },
         { name: "23-Jun", labels: Object.values(schemeNames), values: Object.keys(schemeNames).map(k => +((schemes[k]||[])[1]||0)/1e5) },
         { name: "24-Jun", labels: Object.values(schemeNames), values: Object.keys(schemeNames).map(k => +((schemes[k]||[])[2]||0)/1e5) }],
        { x: 0.3, y: 4.55, w: 6.2, h: 0.9, barDir: "col", barGrouping: "clustered",
          chartColors: [NAVY, GOLD, "4A90D9"],
          chartArea: { fill: { color: WHITE }, roundedCorners: true },
          catAxisLabelColor: MID_TEXT, valAxisLabelColor: MID_TEXT,
          catGridLine: { style: "none" }, valGridLine: { color: "E2E8F0", size: 0.5 },
          showValue: false, showLegend: true, legendPos: "r", legendFontSize: 8, showTitle: false,
          catAxisLabelFontSize: 8, valAxisLabelFontSize: 7 });

      const schemeAmts = Object.entries(schemeNames).map(([key, label]) => ({
        label, val: sum(schemes[key] || [])
      })).filter(x => x.val > 0);

      s.addChart(pres.charts.PIE, [{
        name: "Scheme Mix",
        labels: schemeAmts.map(x => x.label),
        values: schemeAmts.map(x => +(x.val/1e5).toFixed(1))
      }], {
        x: 6.6, y: 4.25, w: 3.1, h: 1.25,
        chartColors: [NAVY, GOLD, "4A90D9", ACCENT_GREEN, "8B5CF6"],
        chartArea: { fill: { color: WHITE }, roundedCorners: true },
        showPercent: true, showLegend: false, dataLabelColor: WHITE, dataLabelFontSize: 8,
        showTitle: true, title: "3-Day Scheme Mix", titleFontSize: 10, titleColor: NAVY, titleFontFace: "Cambria"
      });
    }

    const topScheme = Object.entries(schemeNames)
      .map(([key, label]) => ({ label, total: sum(schemes[key] || []) }))
      .sort((a, b) => b.total - a.total)[0];

    const insights = [
      { label: topScheme ? `${topScheme.label} dominant` : "Top scheme", val: topScheme ? crore(topScheme.total) : "—", color: NAVY },
      { label: "Best collection day", val: dates[totalSchemes.indexOf(Math.max(...totalSchemes))] || "—", color: "1B5E8A" },
      { label: "3-Day scheme total", val: crore(sum(totalSchemes)), color: ACCENT_GREEN },
    ];
    insights.forEach((ins, i) => {
      const x = 0.3 + i * 3.07;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 5.1, w: 2.9, h: 0.42, fill: { color: ins.color }, line: { color: ins.color }, rectRadius: 0.06 });
      s.addText(`${ins.label}: ${ins.val}`, { x: x + 0.1, y: 5.13, w: 2.7, h: 0.35, fontSize: 8.5, bold: true, color: WHITE, fontFace: "Calibri", align: "center" });
    });
  }

  await pres.writeFile({ fileName: outputPath });
  return outputPath;
}

module.exports = { generatePresentation };
