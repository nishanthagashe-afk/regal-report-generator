# Regal Group — Daily Fund Position Report Generator

Upload the daily fund position PDF → get a 13-slide PowerPoint + PDF report instantly.

---

## Deploy in 10 minutes on Render (free)

### Step 1 — Push to GitHub
1. Create a free account at https://github.com
2. Create a new repository (e.g. `regal-report-generator`)
3. Upload all files from this folder into that repository

### Step 2 — Deploy on Render
1. Go to https://render.com and sign up (free)
2. Click **New → Web Service**
3. Connect your GitHub repository
4. Fill in these settings:
   - **Name**: regal-report-generator
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
5. Under **Environment Variables**, click **Add Variable**:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your Anthropic API key (get one at https://console.anthropic.com)
6. Click **Create Web Service**

Render will give you a URL like: `https://regal-report-generator.onrender.com`

**Share that URL with your team. Anyone can open it, upload the PDF, and download the report — no account needed.**

---

## Deploy on Vercel (alternative)

Vercel works best for frontends. For this app (which has a Node.js backend), use Render instead.

---

## Get an Anthropic API Key

1. Go to https://console.anthropic.com
2. Sign up or log in
3. Click **API Keys → Create Key**
4. Copy the key and paste it as `ANTHROPIC_API_KEY` in your Render environment variables

Cost: roughly $0.01–0.05 per report (very cheap).

---

## Files in this package

| File | Purpose |
|------|---------|
| `server.js` | Express backend — handles upload, PDF parsing, AI extraction, report generation |
| `report-generator.js` | Full 13-slide PowerPoint builder |
| `public/index.html` | The web page your team visits |
| `package.json` | Node.js dependencies |

---

## Local testing (optional)

```bash
cd regal-report-app
npm install
ANTHROPIC_API_KEY=your-key-here node server.js
# Open http://localhost:3000
```

---

## PDF format

The uploaded PDF must follow the same layout as the daily fund position report:
- Page 1: CC limits table (Regal Jewellers PVT Ltd, India PVT Ltd, Optimum LLP)
- Page 2: Current account balances
- Page 3: Daily cash flow statement (sales, old gold, schemes, bank loans, outflows)
- Page 4: Payment details (jewellery vendors, opex, capex, salary, tax)

If the PDF format changes, the AI extraction still adapts — but let your IT team know to test after any format change.

---

## Support

For any issues, contact your report admin or raise a request with the IT team.
