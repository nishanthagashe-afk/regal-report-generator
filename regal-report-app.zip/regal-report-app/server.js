const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const os = require("os");
const Anthropic = require("@anthropic-ai/sdk");
const pdfParse = require("pdf-parse");
const archiver = require("archiver");
const { generatePresentation } = require("./report-generator");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Storage: temp dir ────────────────────────────────────────────────────────
const upload = multer({
  dest: os.tmpdir(),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20 MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "application/pdf") cb(null, true);
    else cb(new Error("Only PDF files are accepted"));
  },
});

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// ── Health check ─────────────────────────────────────────────────────────────
app.get("/health", (req, res) => res.json({ status: "ok" }));

// ── Main upload + generate endpoint ─────────────────────────────────────────
app.post("/generate", upload.single("pdf"), async (req, res) => {
  const tmpFile = req.file?.path;
  const outDir = fs.mkdtempSync(path.join(os.tmpdir(), "regal-"));

  try {
    if (!req.file) return res.status(400).json({ error: "No PDF uploaded" });

    // 1. Extract text from PDF
    const pdfBuffer = fs.readFileSync(tmpFile);
    const pdfData = await pdfParse(pdfBuffer);
    const pdfText = pdfData.text;

    // 2. Use Claude to extract structured data from the PDF text
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

    const extractionPrompt = `You are a financial data extractor for the Regal Group of Companies fund position report.

Extract ALL data from this fund position PDF text and return a single valid JSON object.
The JSON must have EXACTLY this structure — fill every field from the PDF or use null if missing:

{
  "reportDate": "DD-MM-YYYY",
  "entities": {
    "regalJewellersPvtLtd": {
      "sanctioned": 0,
      "availed": 0,
      "utilised": 0,
      "available": 0,
      "banks": [
        { "name": "", "accountNo": "", "nature": "CC", "sanctionDate": "", "sanctioned": 0, "availed": 0, "utilised": 0, "available": 0 }
      ]
    },
    "regalJewellersIndiaPvtLtd": {
      "sanctioned": 0, "availed": 0, "utilised": 0, "available": 0,
      "banks": []
    },
    "optimumJewellersLlp": {
      "sanctioned": 0, "availed": 0, "utilised": 0, "available": 0,
      "banks": []
    }
  },
  "currentAccountBalance": 0,
  "currentAccounts": [
    { "entity": "", "location": "", "state": "", "bank": "", "amount": 0 }
  ],
  "cashFlow": {
    "dates": [],
    "salesByBranch": {
      "TVM": [], "EKM": [], "CLT": [], "KNR": [], "PKD": [], "TCR": [],
      "ESM": [], "ERJ": [], "KRJ": [], "KMNLI": [], "MLSWRM": [], "MRTHLI": [], "JYR": [], "HSR": []
    },
    "oldGoldByBranch": {
      "TVM": [], "EKM": [], "CLT": [], "KNR": [], "PKD": [], "TCR": [],
      "ESM": [], "ERJ": [], "KRJ": [], "KMNLI": [], "MLSWRM": [], "MRTHLI": [], "JYR": [], "HSR": []
    },
    "schemeCollections": {
      "Regalia": [], "Akshyanidhi": [], "GoldGram": [], "Swarnaraksha": [], "Swayamvara": []
    },
    "totalSales": [],
    "totalOldGold": [],
    "totalSchemes": [],
    "loanInflow": [],
    "totalInflow": [],
    "opex": [],
    "capex": [],
    "salary": [],
    "goldPurchasePayments": [],
    "oldGoldPayments": [],
    "taxPayments": [],
    "totalOutflow": []
  },
  "jewelleryVendorPayments": [
    { "party": "", "nature": "", "type": "", "showroom": "", "amount": 0 }
  ],
  "opexPayments": [
    { "party": "", "type": "", "showroom": "", "amount": 0 }
  ],
  "capexPayments": [
    { "party": "", "type": "", "showroom": "", "amount": 0 }
  ],
  "salaryPayments": [
    { "party": "", "type": "", "showroom": "", "amount": 0 }
  ],
  "taxPayments": [
    { "party": "", "type": "", "showroom": "", "amount": 0 }
  ]
}

Return ONLY the raw JSON. No markdown, no backticks, no explanation.

PDF TEXT:
${pdfText}`;

    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 8000,
      messages: [{ role: "user", content: extractionPrompt }],
    });

    const rawJson = response.content[0].text.trim()
      .replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "");

    let data;
    try {
      data = JSON.parse(rawJson);
    } catch (e) {
      console.error("JSON parse failed:", rawJson.slice(0, 500));
      return res.status(500).json({ error: "Failed to parse extracted data from PDF. Please check the PDF format." });
    }

    // 3. Generate PowerPoint
    const pptxPath = path.join(outDir, `Fund_Position_${data.reportDate || "Report"}.pptx`);
    await generatePresentation(data, pptxPath);

    // 4. Convert to PDF using LibreOffice (if available) or just serve pptx
    let pdfPath = null;
    try {
      const { execSync } = require("child_process");
      execSync(`libreoffice --headless --convert-to pdf "${pptxPath}" --outdir "${outDir}"`, { timeout: 60000 });
      const pdfName = path.basename(pptxPath, ".pptx") + ".pdf";
      pdfPath = path.join(outDir, pdfName);
    } catch (e) {
      console.warn("LibreOffice not available — skipping PDF conversion:", e.message);
    }

    // 5. Bundle into a zip if both files exist, else just send pptx
    if (pdfPath && fs.existsSync(pdfPath)) {
      const zipPath = path.join(outDir, "Regal_Report.zip");
      await new Promise((resolve, reject) => {
        const output = fs.createWriteStream(zipPath);
        const archive = archiver("zip");
        archive.on("error", reject);
        output.on("close", resolve);
        archive.pipe(output);
        archive.file(pptxPath, { name: path.basename(pptxPath) });
        archive.file(pdfPath, { name: path.basename(pdfPath) });
        archive.finalize();
      });
      res.download(zipPath, "Regal_Report.zip", () => {
        fs.rmSync(outDir, { recursive: true, force: true });
      });
    } else {
      res.download(pptxPath, path.basename(pptxPath), () => {
        fs.rmSync(outDir, { recursive: true, force: true });
      });
    }
  } catch (err) {
    console.error(err);
    fs.rmSync(outDir, { recursive: true, force: true });
    res.status(500).json({ error: err.message || "Report generation failed" });
  } finally {
    if (tmpFile && fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
  }
});

app.listen(PORT, () => console.log(`Regal Report Generator running on port ${PORT}`));
